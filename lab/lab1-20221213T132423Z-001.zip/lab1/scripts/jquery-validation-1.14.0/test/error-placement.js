48300086676792937": {
      "message": "هل تريد تجاهل تقديم التعليقات؟"
   },
   "4163185390680253103": {
      "message": "خلل أو خطأ"
   },
   "4246483347873264186": {
      "message": "تم رفض طلب مشاركة العرض. يرجى الانتظار قبل المحاولة مرة أخرى."
   },
   "4528089202128275824": {
      "message": "تعذّر الإرسال. يرجى المحاولة مرة أخرى."
   },
   "4575332923598659024": {
      "message": "‏تعذر حل اسم Hangout. يرجى التحقق من الاسم وإعادة المحاولة."
   },
   "4592127349908255218": {
      "message": "غير واضحة"
   },
   "4756056595565370923": {
      "message": "تعذّر إرسال التعليقات. جارٍ إعادة المحاولة..."
   },
   "492097680647953484": {
      "message": "طلب ميزة"
   },
   "5014364904504073524": {
      "message": "ممتاز"
   },
   "5028289843569700466": {
      "message": "‏تساعدنا تعليقاتك في تحسين Google Cast ونقدّر لك ذلك. للحصول على مساعدة بشأن تحرّي مشاكل الإرسال وإصلاحها، يرجى الرجوع إلى $START_LINK$مركز المساعدة$END_LINK$.",
      "placeholders": {
         "END_LINK": {
            "content": "$1"
         },
         "START_LINK": {
            "content": "$2"
         }
      }
   },
   "5028289843569700466_ph": {
      "message": "\u003C/a>\u003Ca href=\"https://support.google.com/chromecast/troubleshooter/2995236\">"
   },
   "5363086287710390513": {
      "message": "مقبولة"
   },
   "5375576275991472719": {
      "message": "‏رائعة - HD"
   },
   "5385436389563925676": {
      "message": "‏جهاز الكمبيوتر الشخصي وجهاز Chromecast متصلان بشبكة Wi-Fi واحدة"
   },
   "5440055726839070415": {
      "message": "ما نوع التعليقات التي تقدمها؟"
   },
   "545449835455981095": {
      "message": "صوت نظام الإرسال غير متوافق على هذا الجهاز."
   },
   "5465034684300203467": {
      "message": "‏ما المحتوى/عنوان URL الذي كنت ترسله؟"
   },
   "5485620192329479690": {
      "message": "إرسال سجلات تصحيح الأخطاء (موصى به)"
   },
   "5699813974548050528": {
      "message": "‏مقبولة - FM"
   },
   "5723583529370342957": {
      "message": "يتعثر بشكل عَرضي"
   },
   "5910595154486533449": {
      "message": "ضعيفة"
   },
   "5991427458288444010": {
      "message": "لم يتم الرد على طلب مشاركة العرض."
   },
   "6063910461797960050": {
      "message": "‏تحكم استخدام Hangouts سياسة خصوصية Google."
   },
   "6086448804586867636": {
      "message": "* مطلوب"
   },
   "642051245326856511": {
      "message": "يرجى إدخال تعليقاتك هنا: $START_SPAN$*$END_SPAN$",
      "placeholders": {
         "END_SPAN": {
            "content": "$1"
         },
         "START_SPAN": {
            "content": "$2"
         }
      }
   },
   "642051245326856511_ph": {
      "message": "\u003C/span>\u003Cspan class=\"required-message\" ng-show=\"!top.sufficientFeedback\">"
   },
   "6585975561839203683": {
      "message": "لم أحاول"
   },
   "6614468912728530636": {
      "message": "غير قابل للمشاهدة"
   },
   "6963873398546068901": {
      "message": "‏تحذير - تم تفعيل تسجيل الدخول التفصيلي؛ وقد تتضمن السجلات أدناه عناوين URL أو معلومات أخرى حساسة. يرجى مراجعتها والتأكد من رغبتك في إرسال هذه المعلومات."
   },
   "6997602168024654529": {
      "message": "لست متأكدًا"
   },
   "7156560800952850585": {
      "message": "‏يرجى إخبارنا بما يحدث في Google Cast."
   },
   "715869212995214079": {
      "message": "إرسال $START_LINK$سجلات تصحيح الأخطاء$END_LINK$ (موصى به)",
      "placeholders": {
         "END_LINK": {
            "content": "$1"
         },
         "START_LINK": {
            "content": "$2"
         }
      }
   },
   "715869212995214079_ph": {
      "message": "\u003C/a>\u003Ca href=\"\">"
   },
   "7603034707785674700": {
      "message": "كتم الصوت"
   },
   "7735695102441495789": {
      "message": "‏لم يكن هناك عدد كافٍ من المشاركين في Hangout حتى تظل نشطة."
   },
   "7824803162979416790": {
      "message": "‏جهاز الكمبيوتر الشخصي وجهاز Chromecast متصلان بشبكتي Wi-Fi مختلفتين (على سبيل المثال، 2.4 غيغا هرتز مقابل 5 غيغا هرتز)"
   },
   "7876724262035435114": {
      "message": "سجلات الجهاز والإرسال"
   },
   "8009014317872238527": {
      "message": "إعادة الصوت"
   },
   "8083429352755760987": {
      "message": "جودة الصوت"
   },
   "8205999658352447129": {
      "message": "يتقطع"
   },
   "8330636888136075045": {
      "message": "تفاصيل جودة النسخ المطابق $START_SPAN$*$END_SPAN$",
      "placeholders": {
         "END_SPAN": {
            "content": "$1"
         },
         "START_SPAN": {
            "content": "$2"
         }
      }
   },
   "8330636888136075045_ph": {
      "message": "\u003C/span>\u003Cspan class=\"required-message\" ng-show=\"!top.sufficientFeedback\">"
   },
   "843316808366399491": {
      "message": "ضعيفة"
   },
   "845494741086179740": {
      "message": "‏جهاز الكمبيوتر الشخصي متصل بشكبة سلكية وجهاز Chromecast متصل بشبكة Wi-Fi"
   },
   "8515148417333877999": {
      "message": "جيدة"
   },
   "8530815930928232626": {
      "message": "جودة الفيديو"
   },
   "8636962961150071298": {
      "message": "شريط تمرير البحث"
   },
   "8706273405040403641": {
      "message": "شكرًا لك على إرسال التعليقات."
   },
   "9059560719840598868": {
      "message": "إرسال تعليقات"
   },
   "9120942669794506861": {
      "message": "‏هل لديك شبكة افتراضية خاصة (VPN) أو خادم وكيل أو جدار ناري أو برنامج NAS مثبت؟"
   },
   "9211708838274008657": {
      "message": "تعذر إرسال التعليقات. يرجى إعادة المحاولة لاحقًا."
   },
   "MEDIA_ROUTER_ADDITIONAL_COMMENTS": {
      "message": "2145752429973207616"
   },
   "MEDIA_ROUTER_AUDIO_QUALITY": {
      "message": "8083429352755760987"
   },
   "MEDIA_ROUTER_CANCEL_BUTTON": {
      "message": "2159130950882492111"
   },
   "MEDIA_ROUTER_CONTENT_QUESTION": {
      "message": "5465034684300203467"
   },
   "MEDIA_ROUTER_DID_NOT_TRY": {
      "message": "6585975561839203683"
   },
   "MEDIA_ROUTER_FEEDBACK_EMAIL_FIELD": {
      "message": "4094392217219068632"
   },
   "MEDIA_ROUTER_FEEDBACK_FORM_DESCRIPTION": {
      "message": "5028289843569700466"
   },
   "MEDIA_ROUTER_FEEDBACK_HEADER": {
      "message": "7156560800952850585"
   },
   "MEDIA_ROUTER_FEEDBACK_PROMPT": {
      "message": "642051245326856511"
   },
   "MEDIA_ROUTER_FEEDBACK_REQUIRED": {
      "message": "6086448804586867636"
   },
   "MEDIA_ROUTER_FEEDBACK_TYPE_QUESTION": {
      "message": "5440055726839070415"
   },
   "MEDIA_ROUTER_MIRRORING_QUALITY_SUBHEADING": {
      "message": "8330636888136075045"
   },
   "MEDIA_ROUTER_NETWORK_DIFFERENT_WIFI": {
      "message": "7824803162979416790"
   },
   "MEDIA_ROUTER_NETWORK_QUESTION": {
      "message": "1213957982723875920"
   },
   "MEDIA_ROUTER_NETWORK_SAME_WIFI": {
      "message": "5385436389563925676"
   },
   "MEDIA_ROUTER_NETWORK_WIRED_PC": {
      "message": "845494741086179740"
   },
   "MEDIA_ROUTER_NO": {
      "message": "3542042671420335679"
   },
   "MEDIA_ROUTER_PRIVACY_DATA_USAGE": {
      "message": "4097220110929447276"
   },
   "MEDIA_ROUTER_SEND_BUTTON": {
      "message": "9059560719840598868"
   },
   "MEDIA_ROUTER_SEND_LOGS": {
      "message": "715869212995214079"
   },
   "MEDIA_ROUTER_SETUP_VISIBILITY_QUESTION": {
      "message": "1850397500312020388"
   },
   "MEDIA_ROUTER_SOFTWARE_QUESTION": {
      "message": "9120942669794506861"
   },
   "MEDIA_ROUTER_UNKNOWN": {
      "message": "6997602168024654529"
   },
   "MEDIA_ROUTER_VIDEO_QUALITY": {
      "message": "8530815930928232626"
   },
   "MEDIA_ROUTER_VIDEO_SMOOTHNESS": {
      "message": "1428448869078126731"
   },
   "MEDIA_ROUTER_YES": {
      "message": "2807800733729323332"
   },
   "MSG_FAILED_TO_CAST": {
      "message": "4528089202128275824"
   },
   "MSG_KNOCK_DENIED": {
      "message": "4246483347873264186"
   },
   "MSG_KNOCK_TIMEOUT": {
      "message": "5991427458288444010"
   },
   "MSG_MR_CONNECT_FAILED": {
      "message": "1522140683318860351"
   },
   "MSG_MR_FEEDBACK_AUDIO_ACCEPTABLE": {
      "message": "5699813974548050528"
   },
   "MSG_MR_FEEDBACK_AUDIO_GOOD": {
      "message": "8515148417333877999"
   },
   "MSG_MR_FEEDBACK_AUDIO_PERFECT": {
      "message": "1636686747687494376"
   },
   "MSG_MR_FEEDBACK_AUDIO_POOR": {
      "message": "843316808366399491"
   },
   "MSG_MR_FEEDBACK_AUDIO_UNINTELLIGIBLE": {
      "message": "4592127349908255218"
   },
   "MSG_MR_FEEDBACK_DISCARD_CONFIRMATION": {
      "message": "4148300086676792937"
   },
   "MSG_MR_FEEDBACK_FINE_LOGS_WARNING": {
      "message": "6963873398546068901"
   },
   "MSG_MR_FEEDBACK_LOGS_HEADER": {
      "message": "7876724262035435114"
   },
   "MSG_MR_FEEDBACK_NA": {
      "message": "2194670894476780934"
   },
   "MSG_MR_FEEDBACK_OK": {
      "message": "3567591856726172993"
   },
   "MSG_MR_FEEDBACK_RESENDING": {
      "message": "4756056595565370923"
   },
   "MSG_MR_FEEDBACK_SENDING": {
      "message": "3219866268410307919"
   },
   "MSG_MR_FEEDBACK_SEND_FAIL": {
      "message": "9211708838274008657"
   },
   "MSG_MR_FEEDBACK_SEND_LOGS": {
      "message": "5485620192329479690"
   },
   "MSG_MR_FEEDBACK_SEND_SUCCESS": {
      "message": "8706273405040403641"
   },
   "MSG_MR_FEEDBACK_TYPE_BUG_OR_ERROR": {
      "message": "4163185390680253103"
   },
   "MSG_MR_FEEDBACK_TYPE_DISCOVERY": {
      "message": "128276876460319075"
   },
   "MSG_MR_FEEDB