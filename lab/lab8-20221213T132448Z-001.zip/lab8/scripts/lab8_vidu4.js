// JavaScript Document
function MauNen()
{
	document.bgColor=document.frm.mau.options[document.frm.mau.selectedIndex].value;
}