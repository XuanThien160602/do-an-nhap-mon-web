<?php
print_r($_REQUEST);
echo "<br/><br/><br/><br/><br/><br/>";
print_r($_FILES);
?>